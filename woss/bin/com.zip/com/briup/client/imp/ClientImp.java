package com.briup.client.imp;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.Properties;

import com.briup.client.Client;
import com.briup.model.BIDR;

public class ClientImp implements Client{
	private Socket client;  
	
	@Override
	public void init(Properties properties) {
		try {
			client = new Socket("127.0.0.1", 8888);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void send(Collection<BIDR> collection) throws Exception {
		ObjectOutputStream oos = new ObjectOutputStream(client.getOutputStream());
		oos.writeObject(collection);
		oos.flush();
	}

}
