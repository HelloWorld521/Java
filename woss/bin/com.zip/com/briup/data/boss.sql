drop table t_detail_1
;

drop table t_detail_2
;

drop table t_detail_3
;

drop table t_detail_4
;


drop table t_detail_5
;


drop table t_detail_6
;


drop table t_detail_7
;

drop table t_detail_8
;

drop table t_detail_9
;

drop table t_detail_10
;

drop table t_detail_11
;

drop table t_detail_12
;

drop table t_detail_13
;

drop table t_detail_14
;

drop table t_detail_15
;

drop table t_detail_16
;

drop table t_detail_17
;

drop table t_detail_18
;

drop table t_detail_19
;

drop table t_detail_20
;

drop table t_detail_21
;

drop table t_detail_22
;

drop table t_detail_23
;

drop table t_detail_24
;

drop table t_detail_25
;

drop table t_detail_26
;

drop table t_detail_27
;

drop table t_detail_28
;


drop table t_detail_29
;

drop table t_detail_30
;

drop table t_detail_31
;

CREATE TABLE t_detail_1(
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;

CREATE TABLE t_detail_2 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_3 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_4 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_5 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_6 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_7 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_8 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_9 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_10 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_11 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_12 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_13 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_14 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_15 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_16 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_17 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_18 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_19 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_20 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_21 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_22 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_23 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_24 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_25 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_26 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_27 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_28 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_29(
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_30 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;


CREATE TABLE t_detail_31 (
	login_name	VARCHAR2(10) ,	
	login_ip	 	VARCHAR2(32),	
	login_date	DATE,
	logout_date	DATE,
	lab_ip		VARCHAR2(32),	
	time_duration	NUMBER(10)
)
;



