package com.briup.server.imp;

import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.Collection;

import com.briup.model.BIDR;

public class ServerThread extends Thread{
	private Socket client;
	private Collection<BIDR> bidrs;
	public ServerThread(){}
	public ServerThread(Socket client){
		this.client = client;
	}
	@Override
	public void run() {
		try {
			ObjectInputStream ois = new ObjectInputStream(client.getInputStream());
			bidrs = (Collection<BIDR>) ois.readObject();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
