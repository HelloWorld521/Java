package com.briup.server.imp;

import java.util.Collection;
import java.util.Properties;

import com.briup.model.BIDR;
import com.briup.server.DBStore;

public class DBStoreImp implements DBStore{

	@Override
	public void init(Properties properties) {
		
	}

	@Override
	public void saveToDB(Collection<BIDR> collection) throws Exception {
		
	}
	
}
