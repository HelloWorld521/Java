package com.briup.server.imp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

import com.briup.server.imp.ServerThread;
import com.briup.server.Server;

public class ServerImp implements Server{
	private ServerSocket ss;
	
	@Override
	public void init(Properties properties) {
		try {
			ss=new ServerSocket(8888);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void revicer() throws Exception {
		Socket client = ss.accept();
		ServerThread thread = new ServerThread(client);
		thread.start();
		thread.join();
	}

	@Override
	public void shutdown() {
		
	}
	
}
