package com.briup.main;

import java.util.Properties;

import com.briup.server.imp.ServerImp;

/**
 * @author Chen
 * 服务器启动
 * */
public class ServerMain {
	public static void main(String[] args) throws Exception {
		ServerImp server = new ServerImp();
		Properties properties=null;
		server.init(properties);
		while(true){
			server.revicer();
		}
	}	
}
