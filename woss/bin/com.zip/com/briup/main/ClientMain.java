package com.briup.main;

import java.util.Properties;

import com.briup.client.imp.ClientImp;
import com.briup.client.imp.GatherImp;

/**
 * @author Chen
 * 客户端启动
 * */
public class ClientMain {
	public static void main(String[] args) throws Exception {
		ClientImp client = new ClientImp();
		GatherImp gather = new GatherImp();
		Properties properties=null;
		client.init(properties);
		client.send(gather.gather());
	}
}
